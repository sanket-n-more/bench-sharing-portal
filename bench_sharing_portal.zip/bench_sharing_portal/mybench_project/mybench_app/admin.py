# mybench_app/admin.py

from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.models import Group
from .models import User, ResourceType, Resource, Booking

class UserAdmin(BaseUserAdmin):
    model = User
    # Use the fields that exist in your custom User model
    list_display = ('username', 'user_type', 'is_staff')  # Include is_staff if needed

    fieldsets = (
        (None, {'fields': ('username', 'password')}),
        ('Personal info', {'fields': ('first_name', 'last_name', 'email', 'user_type')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'user_permissions')}),
        ('Important dates', {'fields': ('last_login', 'date_joined')}),
    )

    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'password1', 'password2', 'user_type'),
        }),
    )

    search_fields = ('username',)
    ordering = ('username',)

class ResourceTypeAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')

class ResourceAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'resource_type', 'description', 'added_on', 'booked_by_user', 'booked_date')
    list_filter = ('resource_type', 'added_on')
    search_fields = ('name', 'description')

class BookingAdmin(admin.ModelAdmin):
    list_display = ('id', 'resource', 'user', 'booked_date', 'released_date')
    list_filter = ('booked_date', 'released_date')
    search_fields = ('user__username', 'resource__name')

admin.site.register(ResourceType, ResourceTypeAdmin)
admin.site.register(Resource, ResourceAdmin)
admin.site.register(Booking, BookingAdmin)
admin.site.register(User, UserAdmin)
# Optionally unregister Group if not using
admin.site.unregister(Group)
