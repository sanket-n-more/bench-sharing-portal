from django.urls import path
from . import views

urlpatterns = [
    path('', views.dashboard, name='home'),
    path('manage-resources/', views.manage_resources, name='manage_resources'),
    path('view-resources/', views.view_resources, name='view_resources'),
    path('release-resource/<int:resource_id>/', views.release_resource, name='release_resource'),  # Updated URL pattern
    path('booking-log/', views.booking_log, name='booking_log'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('book-resource/<int:resource_id>/', views.book_resource, name='book_resource'),
    path('login/', views.login, name='login'),
    path('register/', views.register, name='register'),
    path('logout/', views.logout, name='logout'),
    path('add-seating-space/', views.add_seating_space, name='add_seating_space'),
    path('add-resource/', views.add_resource, name='add_resource'),
    path('delete_resource/<int:resource_id>/', views.delete_resource, name='delete_resource'),
]
