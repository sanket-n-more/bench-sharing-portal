from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import User, ResourceType, Resource, Booking


class CompanyRegistrationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ('username', 'password1', 'password2')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.user_type = 1  # Assuming 1 represents 'Company'
        if commit:
            user.save()
        return user


class ResourceTypeForm(forms.ModelForm):
    class Meta:
        model = ResourceType
        fields = ['name']


class ResourceForm(forms.ModelForm):
    class Meta:
        model = Resource
        fields = ['name', 'resource_type', 'description']
        widgets = {
            'resource_type': forms.Select(attrs={'class': 'form-control'}),  # Display as dropdown
        }


class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['resource', 'booked_date']


class SeatingSpaceForm(forms.Form):
    number_of_spaces = forms.IntegerField(min_value=1, label='Number of Seating Spaces')
    description = forms.CharField(max_length=255, required=False, label='Description')



class BookingLogFilterForm(forms.Form):
    resource_type = forms.ModelChoiceField(
        queryset=ResourceType.objects.all(), 
        required=False,
        label="Resource Type",
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    start_date = forms.DateField(
        required=False,
        label="Start Date",
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'})
    )
    end_date = forms.DateField(
        required=False,
        label="End Date",
        widget=forms.DateInput(attrs={'type': 'date', 'class': 'form-control'})
    )
    search_query = forms.CharField(
        required=False,
        label="Search",
        widget=forms.TextInput(attrs={'class': 'form-control'})
    )
