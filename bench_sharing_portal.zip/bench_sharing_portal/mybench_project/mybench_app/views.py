from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login as auth_login
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from .forms import CompanyRegistrationForm, SeatingSpaceForm, ResourceForm,BookingLogFilterForm
from .models import User, ResourceType, Resource, Booking
from django.contrib.auth import logout as auth_logout
from django.contrib.auth import authenticate, login as auth_login
from django.contrib import messages
from datetime import datetime
from django.http import HttpResponseForbidden, HttpResponseNotAllowed
from django.db.models import Q


def logout(request):
    auth_logout(request)
    return redirect('login')


def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect('dashboard')
        else:
            messages.error(request, 'Invalid username or password.')
    return render(request, 'app/login.html')


def register(request):
    if request.method == 'POST':
        form = CompanyRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save()
            auth_login(request, user)  # Log in the user immediately after registration
            messages.success(request, 'Account created successfully.')
            return redirect('dashboard')
        else:
            messages.error(request, 'Account creation failed. Please correct the errors below.')
    else:
        form = CompanyRegistrationForm()
    
    return render(request, 'app/register.html', {'form': form})



@login_required
def dashboard(request):
    resource_type_names = {
        'seating_space': 'Seating Space',
        'engineer': 'Engineer',
        'product_license': 'Product License',
        'others': 'Others'
    }

    resource_counts = {}

    for key, display_name in resource_type_names.items():
        try:
            resource_type = ResourceType.objects.get(name=key)
            count = Resource.objects.filter(
                resource_type=resource_type,
                booked_by_user__isnull=True
            ).count()
            resource_counts[key] = {
                'count': count,
                'display_name': display_name,
                'resource_type_id': resource_type.id
            }
        except ResourceType.DoesNotExist:
            resource_counts[key] = {
                'count': 0,
                'display_name': display_name,
                'resource_type_id': None
            }

    context = {
        'resource_counts': resource_counts
    }
    return render(request, 'app/dashboard.html', context)


@login_required
def manage_resource_types(request):
    resource_types = ResourceType.objects.all()
    context = {
        'resource_types': resource_types
    }
    return render(request, 'app/manage_resource_types.html', context)


@login_required
def manage_resources(request):
    if request.method == 'POST':
        resource_type_id = request.POST.get('resource_type')
        resource_type = get_object_or_404(ResourceType, id=resource_type_id)

        name = request.POST.get('name')
        description = request.POST.get('description')

        Resource.objects.create(
            name=name,
            resource_type=resource_type,
            description=description
        )
        return redirect('manage_resources')

    resource_types = ResourceType.objects.all()
    selected_type = request.GET.get('resource_type', '')

    if selected_type:
        resources = Resource.objects.filter(
            booked_by_user=request.user,
            resource_type_id=selected_type
        )
    else:
        resources = Resource.objects.filter(booked_by_user=request.user)

    context = {
        'resource_types': resource_types,
        'resources': resources,
        'selected_type': selected_type
    }
    return render(request, 'app/manage_resources.html', context)



@login_required
def view_resources(request):
    resource_type_name = request.GET.get('resource_type_name')

    if request.user.is_superuser:
        # Admins can see all resources
        if resource_type_name:
            resources = Resource.objects.filter(resource_type__name=resource_type_name)
        else:
            resources = Resource.objects.all()
    else:
        # Non-admins can only see available resources
        if resource_type_name:
            resources = Resource.objects.filter(resource_type__name=resource_type_name, booked_by_user__isnull=True)
        else:
            resources = Resource.objects.filter(booked_by_user__isnull=True)
    
    resource_types = ResourceType.objects.all()
    
    context = {
        'resources': resources,
        'resource_types': resource_types,
        'resource_type_name': resource_type_name
    }
    return render(request, 'app/view_resources.html', context)






@login_required
def book_resource(request, resource_id):
    resource = get_object_or_404(Resource, id=resource_id)

    if not request.user.is_superuser:  # Only companies can book resources
        resource.booked_by_user = request.user
        resource.booked_date = timezone.now()
        resource.save()

        Booking.objects.create(
            resource=resource,
            user=request.user,
            booked_date=timezone.now(),
            action_type='BOOK'
        )
        messages.success(request, 'Resource booked successfully.')
    else:
        messages.error(request, 'Admins cannot book resources.')

    return redirect('view_resources')



@login_required
def release_resource(request, resource_id):
    resource = get_object_or_404(Resource, id=resource_id)
    
    if not request.user.is_superuser and resource.booked_by_user != request.user:
        return HttpResponseForbidden("You do not have permission to release this resource.")
    
    if request.method == 'POST':
        # Record the current booking
        current_booking = Booking.objects.filter(
            resource=resource,
            released_date__isnull=True
        ).first()
        
        if current_booking:
            current_booking.released_date = timezone.now()
            current_booking.save()
        
        # Update the resource to be available
        resource.booked_by_user = None
        resource.booked_date = None  # Ensure this is set to None, as it's not required
        resource.save()
        
        # Create a release log entry
        Booking.objects.create(
            resource=resource,
            user=request.user,
            booked_date=current_booking.booked_date if current_booking else None,
            released_date=timezone.now()  # Use timezone-aware datetime
        )
        
        messages.success(request, 'Resource released successfully.')
        return redirect('view_resources')
    
    return HttpResponseNotAllowed("Invalid request method.")



@login_required
def booking_log(request):
    bookings = Booking.objects.all().select_related('resource', 'user')
    form = BookingLogFilterForm(request.GET or None)

    if form.is_valid():
        # Filter by resource type
        resource_type = form.cleaned_data.get('resource_type')
        if resource_type:
            bookings = bookings.filter(resource__resource_type=resource_type)

        # Filter by date range
        start_date = form.cleaned_data.get('start_date')
        end_date = form.cleaned_data.get('end_date')
        if start_date:
            bookings = bookings.filter(booked_date__gte=start_date)
        if end_date:
            bookings = bookings.filter(released_date__lte=end_date)

        # Search by resource name or user
        search_query = form.cleaned_data.get('search_query')
        if search_query:
            bookings = bookings.filter(
                Q(resource__name__icontains=search_query) |
                Q(user__username__icontains=search_query)
            )

    context = {
        'form': form,
        'bookings': bookings,
        'resource_types': ResourceType.objects.all()  # For the filter dropdown
    }
    return render(request, 'app/booking_log.html', context)


@login_required
def add_seating_space(request):
    if request.method == 'POST':
        form = SeatingSpaceForm(request.POST)
        if form.is_valid():
            number_of_spaces = form.cleaned_data['number_of_spaces']
            description = form.cleaned_data['description']
            resource_type = ResourceType.objects.get(name='seating_space')

            for _ in range(number_of_spaces):
                Resource.objects.create(
                    name='Seating Space',
                    resource_type=resource_type,
                    description=description if description else f"{request.user.username} office",
                    added_on=timezone.now(),
                    booked_by_user=None,  # Ensure the resource is not booked at creation
                    booked_date=None  # Ensure no booking date is set at creation
                )

            messages.success(request, 'Seating spaces added successfully.')
            return redirect('manage_resources')
    else:
        form = SeatingSpaceForm()

    return render(request, 'app/add_seating_space.html', {'form': form})



@login_required
def add_resource(request):
    if request.method == 'POST':
        form = ResourceForm(request.POST)
        if form.is_valid():
            resource_type = form.cleaned_data['resource_type']
            if resource_type.name == 'seating_space':
                form.instance.description = f"{request.user.username} office"
            form.instance.added_on = timezone.now()
            form.instance.booked_by_user = None  # Ensure the resource is not booked at creation
            form.instance.booked_date = None  # Ensure no booking date is set at creation
            form.save()
            messages.success(request, 'Resource added successfully.')
            return redirect('manage_resources')
    else:
        form = ResourceForm()

    return render(request, 'app/add_resource.html', {'form': form})

@login_required
def delete_resource(request, resource_id):
    resource = get_object_or_404(Resource, id=resource_id)
    
    if request.user.is_superuser:
        if resource.booked_by_user:
            # If resource is booked, release it first
            resource.booked_by_user = None
            resource.booked_date = None
            resource.save()
        
        resource.delete()
        messages.success(request, 'Resource deleted successfully.')
    else:
        messages.error(request, 'You do not have permission to delete resources.')

    return redirect('view_resources')
