from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone

class User(AbstractUser):
    USER_TYPE_CHOICES = (
        (0, 'Admin'),
        (1, 'Company'),
    )
    user_type = models.PositiveSmallIntegerField(choices=USER_TYPE_CHOICES, default=1)

class ResourceType(models.Model):
    name = models.CharField(max_length=50)

    def __str__(self):
        return self.name

class Resource(models.Model):
    name = models.CharField(max_length=100)
    resource_type = models.ForeignKey(ResourceType, on_delete=models.CASCADE)
    description = models.TextField()
    added_on = models.DateTimeField(default=timezone.now)
    booked_by_user = models.ForeignKey(User, null=True, blank=True, on_delete=models.SET_NULL, related_name='booked_resources')
    booked_date = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return self.name

class Booking(models.Model):
    ACTION_TYPE_CHOICES = [
        ('BOOK', 'Booked'),
        ('RELEASE', 'Released')
    ]
    resource = models.ForeignKey(Resource, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    booked_date = models.DateTimeField()
    released_date = models.DateTimeField(null=True, blank=True)
    action_type = models.CharField(max_length=10, choices=ACTION_TYPE_CHOICES)

    def __str__(self):
        return f"{self.resource.name} - {self.action_type}"
