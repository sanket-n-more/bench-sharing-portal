-- MySQL dump 10.13  Distrib 8.0.38, for Win64 (x86_64)
--
-- Host: localhost    Database: mybench_db
-- ------------------------------------------------------
-- Server version	8.0.38

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add content type',4,'add_contenttype'),(14,'Can change content type',4,'change_contenttype'),(15,'Can delete content type',4,'delete_contenttype'),(16,'Can view content type',4,'view_contenttype'),(17,'Can add session',5,'add_session'),(18,'Can change session',5,'change_session'),(19,'Can delete session',5,'delete_session'),(20,'Can view session',5,'view_session'),(21,'Can add user',6,'add_user'),(22,'Can change user',6,'change_user'),(23,'Can delete user',6,'delete_user'),(24,'Can view user',6,'view_user'),(25,'Can add resource type',7,'add_resourcetype'),(26,'Can change resource type',7,'change_resourcetype'),(27,'Can delete resource type',7,'delete_resourcetype'),(28,'Can view resource type',7,'view_resourcetype'),(29,'Can add resource',8,'add_resource'),(30,'Can change resource',8,'change_resource'),(31,'Can delete resource',8,'delete_resource'),(32,'Can view resource',8,'view_resource'),(33,'Can add booking',9,'add_booking'),(34,'Can change booking',9,'change_booking'),(35,'Can delete booking',9,'delete_booking'),(36,'Can view booking',9,'view_booking');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_mybench_app_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_mybench_app_user_id` FOREIGN KEY (`user_id`) REFERENCES `mybench_app_user` (`id`),
  CONSTRAINT `django_admin_log_chk_1` CHECK ((`action_flag` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2024-07-25 17:23:33.967867','1','seating_space',1,'[{\"added\": {}}]',7,1),(2,'2024-07-25 17:23:40.418427','2','engineer',1,'[{\"added\": {}}]',7,1),(3,'2024-07-25 17:23:47.772900','3','product_license',1,'[{\"added\": {}}]',7,1),(4,'2024-07-25 17:23:52.733248','4','others',1,'[{\"added\": {}}]',7,1),(5,'2024-07-25 18:52:07.218320','5','Seating Space',3,'',8,1),(6,'2024-07-25 18:52:07.223067','4','Seating Space',3,'',8,1),(7,'2024-07-25 18:52:07.227111','3','Seating Space',3,'',8,1),(8,'2024-07-25 18:52:07.230139','2','Seating Space',3,'',8,1),(9,'2024-07-25 18:52:07.233711','1','Seating Space',3,'',8,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'contenttypes','contenttype'),(9,'mybench_app','booking'),(8,'mybench_app','resource'),(7,'mybench_app','resourcetype'),(6,'mybench_app','user'),(5,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2024-07-25 16:40:03.430795'),(2,'contenttypes','0002_remove_content_type_name','2024-07-25 16:40:03.507678'),(3,'auth','0001_initial','2024-07-25 16:40:03.819103'),(4,'auth','0002_alter_permission_name_max_length','2024-07-25 16:40:03.894723'),(5,'auth','0003_alter_user_email_max_length','2024-07-25 16:40:03.901876'),(6,'auth','0004_alter_user_username_opts','2024-07-25 16:40:03.910972'),(7,'auth','0005_alter_user_last_login_null','2024-07-25 16:40:03.918689'),(8,'auth','0006_require_contenttypes_0002','2024-07-25 16:40:03.923880'),(9,'auth','0007_alter_validators_add_error_messages','2024-07-25 16:40:03.931512'),(10,'auth','0008_alter_user_username_max_length','2024-07-25 16:40:03.941487'),(11,'auth','0009_alter_user_last_name_max_length','2024-07-25 16:40:03.948493'),(12,'auth','0010_alter_group_name_max_length','2024-07-25 16:40:03.966008'),(13,'auth','0011_update_proxy_permissions','2024-07-25 16:40:03.973921'),(14,'auth','0012_alter_user_first_name_max_length','2024-07-25 16:40:03.981850'),(15,'mybench_app','0001_initial','2024-07-25 16:40:04.853024'),(16,'admin','0001_initial','2024-07-25 16:40:05.039020'),(17,'admin','0002_logentry_remove_auto_add','2024-07-25 16:40:05.048818'),(18,'admin','0003_logentry_add_action_flag_choices','2024-07-25 16:40:05.059298'),(19,'sessions','0001_initial','2024-07-25 16:40:05.107588');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mybench_app_booking`
--

DROP TABLE IF EXISTS `mybench_app_booking`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mybench_app_booking` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `booked_date` datetime(6) NOT NULL,
  `released_date` datetime(6) DEFAULT NULL,
  `action_type` varchar(10) NOT NULL,
  `resource_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mybench_app_booking_resource_id_79141378_fk_mybench_a` (`resource_id`),
  KEY `mybench_app_booking_user_id_6663cec0_fk_mybench_app_user_id` (`user_id`),
  CONSTRAINT `mybench_app_booking_resource_id_79141378_fk_mybench_a` FOREIGN KEY (`resource_id`) REFERENCES `mybench_app_resource` (`id`),
  CONSTRAINT `mybench_app_booking_user_id_6663cec0_fk_mybench_app_user_id` FOREIGN KEY (`user_id`) REFERENCES `mybench_app_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mybench_app_booking`
--

LOCK TABLES `mybench_app_booking` WRITE;
/*!40000 ALTER TABLE `mybench_app_booking` DISABLE KEYS */;
INSERT INTO `mybench_app_booking` VALUES (29,'2024-07-26 04:41:01.096269',NULL,'BOOK',31,2),(30,'2024-07-26 04:41:04.051008',NULL,'BOOK',67,2),(31,'2024-07-26 04:41:06.829783',NULL,'BOOK',98,2),(32,'2024-07-26 04:41:16.214911',NULL,'BOOK',102,2),(33,'2024-07-26 04:41:24.916952',NULL,'BOOK',119,2),(34,'2024-07-26 04:41:39.877907',NULL,'BOOK',126,2),(35,'2024-07-26 04:42:07.988881',NULL,'BOOK',11,2),(36,'2024-07-26 04:42:11.464875',NULL,'BOOK',12,2),(37,'2024-07-26 04:42:16.069676',NULL,'BOOK',37,2),(38,'2024-07-26 04:42:16.150124',NULL,'BOOK',37,2),(39,'2024-07-26 04:42:18.607728',NULL,'BOOK',48,2),(40,'2024-07-26 04:42:24.068294',NULL,'BOOK',78,2),(41,'2024-07-26 04:42:31.118285',NULL,'BOOK',95,2),(42,'2024-07-26 04:42:39.852959',NULL,'BOOK',81,2),(43,'2024-07-26 04:43:32.869539',NULL,'BOOK',33,2),(44,'2024-07-26 04:43:34.799553',NULL,'BOOK',13,2),(45,'2024-07-26 04:43:36.248624',NULL,'BOOK',15,2),(46,'2024-07-26 04:43:36.888258',NULL,'BOOK',14,2),(47,'2024-07-26 04:43:37.572648',NULL,'BOOK',17,2),(48,'2024-07-26 04:43:38.164034',NULL,'BOOK',23,2),(49,'2024-07-26 04:43:38.762896',NULL,'BOOK',25,2),(50,'2024-07-26 04:44:12.986635',NULL,'BOOK',20,3),(51,'2024-07-26 04:44:13.005145',NULL,'BOOK',20,3),(52,'2024-07-26 04:44:14.032051',NULL,'BOOK',24,3),(53,'2024-07-26 04:44:14.883833',NULL,'BOOK',27,3),(54,'2024-07-26 04:44:15.581790',NULL,'BOOK',28,3),(55,'2024-07-26 04:44:16.127566',NULL,'BOOK',29,3),(56,'2024-07-26 04:44:17.555500',NULL,'BOOK',26,3),(57,'2024-07-26 04:44:17.994522',NULL,'BOOK',22,3),(58,'2024-07-26 04:44:19.811029',NULL,'BOOK',18,3),(59,'2024-07-26 04:44:20.310016',NULL,'BOOK',16,3),(60,'2024-07-26 04:44:22.572368',NULL,'BOOK',30,3),(61,'2024-07-26 04:44:24.471519',NULL,'BOOK',73,3),(62,'2024-07-26 04:44:39.201365',NULL,'BOOK',103,3),(63,'2024-07-26 04:44:43.890706',NULL,'BOOK',104,3),(64,'2024-07-26 04:44:47.446305',NULL,'BOOK',105,3),(65,'2024-07-26 04:44:50.446145',NULL,'BOOK',106,3),(66,'2024-07-26 04:44:56.485864',NULL,'BOOK',114,3),(67,'2024-07-26 04:45:05.421264',NULL,'BOOK',99,3),(68,'2024-07-26 04:45:09.719731',NULL,'BOOK',96,3),(69,'2024-07-26 04:45:22.882713',NULL,'BOOK',97,3),(70,'2024-07-26 04:45:48.487513',NULL,'BOOK',132,3),(71,'2024-07-26 04:46:10.079629',NULL,'BOOK',107,4),(72,'2024-07-26 04:46:18.054935',NULL,'BOOK',19,4),(73,'2024-07-26 04:46:19.381421',NULL,'BOOK',34,4),(74,'2024-07-26 04:46:19.911252',NULL,'BOOK',32,4),(75,'2024-07-26 04:46:20.312813',NULL,'BOOK',21,4),(76,'2024-07-26 04:46:20.688374',NULL,'BOOK',35,4),(77,'2024-07-26 04:46:21.055413',NULL,'BOOK',38,4),(78,'2024-07-26 04:46:21.375685',NULL,'BOOK',40,4),(79,'2024-07-26 04:46:22.333440',NULL,'BOOK',36,4),(80,'2024-07-26 04:46:27.287546',NULL,'BOOK',109,4),(81,'2024-07-26 04:46:32.401761',NULL,'BOOK',112,4),(82,'2024-07-26 04:46:35.371334',NULL,'BOOK',115,4),(83,'2024-07-26 04:46:39.587105',NULL,'BOOK',129,4),(84,'2024-07-26 04:46:45.824817',NULL,'BOOK',80,4),(85,'2024-07-26 04:46:50.750589',NULL,'BOOK',79,4),(86,'2024-07-26 04:46:57.803724',NULL,'BOOK',91,4),(87,'2024-07-26 04:48:12.120491',NULL,'BOOK',108,5),(88,'2024-07-26 04:48:17.807863',NULL,'BOOK',41,5),(89,'2024-07-26 04:48:18.459266',NULL,'BOOK',42,5),(90,'2024-07-26 04:48:19.039746',NULL,'BOOK',43,5),(91,'2024-07-26 04:48:19.469090',NULL,'BOOK',44,5),(92,'2024-07-26 04:48:22.540169',NULL,'BOOK',63,5),(93,'2024-07-26 04:48:22.978907',NULL,'BOOK',47,5),(94,'2024-07-26 04:48:26.751264',NULL,'BOOK',84,5),(95,'2024-07-26 04:48:29.107972',NULL,'BOOK',76,5),(96,'2024-07-26 04:48:30.795121',NULL,'BOOK',116,5),(97,'2024-07-26 04:48:33.034854',NULL,'BOOK',128,5),(98,'2024-07-26 04:48:35.034701',NULL,'BOOK',141,5),(99,'2024-07-26 04:48:36.405246',NULL,'BOOK',140,5),(100,'2024-07-26 04:48:38.255268',NULL,'BOOK',144,5),(101,'2024-07-26 04:48:39.922352',NULL,'BOOK',143,5),(102,'2024-07-26 04:48:41.527060',NULL,'BOOK',142,5),(103,'2024-07-26 04:49:08.331364',NULL,'BOOK',82,5),(104,'2024-07-26 04:49:12.553099',NULL,'BOOK',85,5),(105,'2024-07-26 04:49:18.099424',NULL,'BOOK',90,5),(106,'2024-07-26 04:49:21.990735',NULL,'BOOK',93,5),(107,'2024-07-26 04:50:45.276102',NULL,'BOOK',131,5),(108,'2024-07-26 04:51:31.052038','2024-07-26 04:53:04.245848','BOOK',39,6),(109,'2024-07-26 04:51:31.682302','2024-07-26 04:53:27.255088','BOOK',50,6),(110,'2024-07-26 04:51:32.262416',NULL,'BOOK',52,6),(111,'2024-07-26 04:51:32.633513',NULL,'BOOK',54,6),(112,'2024-07-26 04:51:33.403991',NULL,'BOOK',56,6),(113,'2024-07-26 04:51:34.748703',NULL,'BOOK',64,6),(114,'2024-07-26 04:51:37.385155','2024-07-26 04:52:50.295703','BOOK',69,6),(115,'2024-07-26 04:51:43.597874',NULL,'BOOK',75,6),(116,'2024-07-26 04:51:48.541093',NULL,'BOOK',77,6),(117,'2024-07-26 04:51:50.133602',NULL,'BOOK',53,6),(118,'2024-07-26 04:51:50.559063',NULL,'BOOK',57,6),(119,'2024-07-26 04:51:51.074508',NULL,'BOOK',59,6),(120,'2024-07-26 04:52:04.310359',NULL,'BOOK',145,6),(121,'2024-07-26 04:52:06.501362',NULL,'BOOK',139,6),(122,'2024-07-26 04:52:09.946155',NULL,'BOOK',121,6),(123,'2024-07-26 04:52:11.613820',NULL,'BOOK',124,6),(124,'2024-07-26 04:52:13.106969',NULL,'BOOK',122,6),(125,'2024-07-26 04:52:14.999485',NULL,'BOOK',123,6),(126,'2024-07-26 04:52:17.068068',NULL,'BOOK',127,6),(127,'2024-07-26 04:52:20.445948',NULL,'BOOK',92,6),(128,'2024-07-26 04:52:24.045507',NULL,'BOOK',101,6),(129,'2024-07-26 04:52:25.956417',NULL,'BOOK',87,6),(130,'2024-07-26 04:51:37.385155','2024-07-26 04:52:50.303704','',69,6),(131,'2024-07-26 04:51:31.052038','2024-07-26 04:53:04.253420','',39,6),(132,'2024-07-26 04:51:31.682302','2024-07-26 04:53:27.262868','',50,6);
/*!40000 ALTER TABLE `mybench_app_booking` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mybench_app_resource`
--

DROP TABLE IF EXISTS `mybench_app_resource`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mybench_app_resource` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `description` longtext NOT NULL,
  `added_on` datetime(6) NOT NULL,
  `booked_date` datetime(6) DEFAULT NULL,
  `booked_by_user_id` bigint DEFAULT NULL,
  `resource_type_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mybench_app_resource_booked_by_user_id_9c17b24d_fk_mybench_a` (`booked_by_user_id`),
  KEY `mybench_app_resource_resource_type_id_a87709e4_fk_mybench_a` (`resource_type_id`),
  CONSTRAINT `mybench_app_resource_booked_by_user_id_9c17b24d_fk_mybench_a` FOREIGN KEY (`booked_by_user_id`) REFERENCES `mybench_app_user` (`id`),
  CONSTRAINT `mybench_app_resource_resource_type_id_a87709e4_fk_mybench_a` FOREIGN KEY (`resource_type_id`) REFERENCES `mybench_app_resourcetype` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mybench_app_resource`
--

LOCK TABLES `mybench_app_resource` WRITE;
/*!40000 ALTER TABLE `mybench_app_resource` DISABLE KEYS */;
INSERT INTO `mybench_app_resource` VALUES (11,'John Smith','Senior Engineer at TechCorp','2024-07-26 04:23:53.378277','2024-07-26 04:42:07.984538',2,2),(12,'Jane Doe','Lead Engineer at InnovateX','2024-07-26 04:23:53.408503','2024-07-26 04:42:11.460826',2,2),(13,'Michael Johnson','Software Engineer at CodeLab','2024-07-26 04:23:53.455431','2024-07-26 04:43:34.795558',2,2),(14,'Emily Davis','Systems Engineer at DevSolutions','2024-07-26 04:23:53.500802','2024-07-26 04:43:36.884129',2,2),(15,'William Brown','Backend Engineer at WebWorks','2024-07-26 04:23:53.548160','2024-07-26 04:43:36.233833',2,2),(16,'Olivia Martinez','Frontend Engineer at UI Studios','2024-07-26 04:23:53.595940','2024-07-26 04:44:20.306555',3,2),(17,'James Wilson','Data Engineer at DataCore','2024-07-26 04:23:53.642689','2024-07-26 04:43:37.568653',2,2),(18,'Sophia Anderson','DevOps Engineer at CloudForge','2024-07-26 04:23:53.690143','2024-07-26 04:44:19.807040',3,2),(19,'Benjamin Taylor','QA Engineer at TestMasters','2024-07-26 04:23:53.737359','2024-07-26 04:46:18.049493',4,2),(20,'Ava Thomas','Embedded Systems Engineer at SmartTech','2024-07-26 04:23:53.785909','2024-07-26 04:44:13.002150',3,2),(21,'Lucas Lee','Network Engineer at NetWise','2024-07-26 04:23:53.818665','2024-07-26 04:46:20.309265',4,2),(22,'Mia Harris','Security Engineer at SecureNet','2024-07-26 04:23:53.849598','2024-07-26 04:44:17.989876',3,2),(23,'Ethan Clark','AI Engineer at AIBrain','2024-07-26 04:23:53.880368','2024-07-26 04:43:38.159867',2,2),(24,'Isabella Lewis','Machine Learning Engineer at MLWorks','2024-07-26 04:23:53.911698','2024-07-26 04:44:14.028730',3,2),(25,'Jacob Walker','Cloud Engineer at CloudSys','2024-07-26 04:23:53.942232','2024-07-26 04:43:38.758908',2,2),(26,'Charlotte Hall','Database Engineer at DataVault','2024-07-26 04:23:53.974526','2024-07-26 04:44:17.551150',3,2),(27,'Logan Allen','Software Architect at ArchiTech','2024-07-26 04:23:54.005064','2024-07-26 04:44:14.879213',3,2),(28,'Amelia Young','Full Stack Engineer at StackLab','2024-07-26 04:23:54.034715','2024-07-26 04:44:15.577613',3,2),(29,'Oliver King','Web Developer at WebDev Inc.','2024-07-26 04:23:54.065700','2024-07-26 04:44:16.122974',3,2),(30,'Harper Scott','iOS Developer at AppleTech','2024-07-26 04:23:54.081943','2024-07-26 04:44:22.568795',3,2),(31,'Elijah Wright','Android Developer at DroidWorks','2024-07-26 04:23:54.114673','2024-07-26 04:41:01.092094',2,2),(32,'Abigail Green','Front-End Developer at DesignNow','2024-07-26 04:23:54.144849','2024-07-26 04:46:19.907030',4,2),(33,'Henry Adams','Back-End Developer at ServerSide','2024-07-26 04:23:54.175241','2024-07-26 04:43:32.865036',2,2),(34,'Evelyn Nelson','UI/UX Designer at DesignPro','2024-07-26 04:23:54.206334','2024-07-26 04:46:19.377431',4,2),(35,'Alexander Carter','Blockchain Developer at BlockTech','2024-07-26 04:23:54.254218','2024-07-26 04:46:20.683427',4,2),(36,'Ella Mitchell','DevOps Specialist at OpsLab','2024-07-26 04:23:54.283968','2024-07-26 04:46:22.328185',4,2),(37,'Jack Roberts','Game Developer at GameForge','2024-07-26 04:23:54.317201','2024-07-26 04:42:16.146135',2,2),(38,'Scarlett Perez','Systems Analyst at SysAnaly','2024-07-26 04:23:54.346421','2024-07-26 04:46:21.051242',4,2),(39,'Daniel Thompson','Integration Engineer at IntegrateX','2024-07-26 04:23:54.377409',NULL,NULL,2),(40,'Lily White','API Developer at APIWorks','2024-07-26 04:23:54.394458','2024-07-26 04:46:21.371122',4,2),(41,'Matthew Harris','IoT Engineer at IoTWorld','2024-07-26 04:23:54.424145','2024-07-26 04:48:17.803208',5,2),(42,'Avery Moore','Performance Engineer at SpeedTech','2024-07-26 04:23:54.456368','2024-07-26 04:48:18.455518',5,2),(43,'Jackson Carter','Automation Engineer at AutoLab','2024-07-26 04:23:54.485710','2024-07-26 04:48:19.034821',5,2),(44,'Sofia Evans','Research Engineer at TechResearch','2024-07-26 04:23:54.517421','2024-07-26 04:48:19.463878',5,2),(45,'Michael Morgan','Consulting Engineer at ConsultTech','2024-07-26 04:23:54.548074',NULL,NULL,2),(46,'Grace Mitchell','Application Engineer at AppWorks','2024-07-26 04:23:54.580918',NULL,NULL,2),(47,'David Murphy','Systems Engineer at SysTech','2024-07-26 04:23:54.611882','2024-07-26 04:48:22.974866',5,2),(48,'Harper James','Product Engineer at ProductLab','2024-07-26 04:23:54.642716','2024-07-26 04:42:18.603324',2,2),(49,'Chloe Walker','Hardware Engineer at HardTech','2024-07-26 04:23:54.674694',NULL,NULL,2),(50,'William Carter','Firmware Engineer at FirmTech','2024-07-26 04:23:54.704668',NULL,NULL,2),(51,'Ella Phillips','Technical Engineer at TechCorp','2024-07-26 04:23:54.736199',NULL,NULL,2),(52,'Mason Johnson','Senior Developer at DevSolutions','2024-07-26 04:23:54.766761','2024-07-26 04:51:32.258427',6,2),(53,'Zoe Brooks','Embedded Software Engineer at SoftTech','2024-07-26 04:23:54.798132','2024-07-26 04:51:50.129526',6,2),(54,'James King','Cloud Solutions Engineer at CloudTech','2024-07-26 04:23:54.830396','2024-07-26 04:51:32.629511',6,2),(55,'Aria Lee','Software Developer at CodeMasters','2024-07-26 04:23:54.862574',NULL,NULL,2),(56,'Michael Roberts','Data Scientist at DataWorks','2024-07-26 04:23:54.893516','2024-07-26 04:51:33.390449',6,2),(57,'Hannah Turner','Senior Data Engineer at DataForge','2024-07-26 04:23:54.925016','2024-07-26 04:51:50.553731',6,2),(58,'Ethan Adams','ML Engineer at MachineLabs','2024-07-26 04:23:54.955758',NULL,NULL,2),(59,'Samantha Harris','Software Engineer at SoftWorks','2024-07-26 04:23:54.987866','2024-07-26 04:51:51.070900',6,2),(60,'Daniel Wilson','DevOps Engineer at DevOpsWorks','2024-07-26 04:23:55.018737',NULL,NULL,2),(61,'Madison Smith','Web Engineer at WebCore','2024-07-26 04:23:55.048431',NULL,NULL,2),(62,'Lucas White','AI Specialist at AICorp','2024-07-26 04:23:55.082556',NULL,NULL,2),(63,'Nora Davis','Database Administrator at DBWorks','2024-07-26 04:23:55.112681','2024-07-26 04:48:22.535669',5,2),(64,'Jackson Martinez','Solutions Engineer at SolutionsX','2024-07-26 04:23:55.143771','2024-07-26 04:51:34.734380',6,2),(65,'Eleanor Young','Hardware Specialist at HardLab','2024-07-26 04:23:55.175016',NULL,NULL,2),(66,'Liam Roberts','Software Analyst at SoftCore','2024-07-26 04:23:55.205018',NULL,NULL,2),(67,'Olivia Johnson','Embedded Engineer at EmbeddedWorks','2024-07-26 04:23:55.237723','2024-07-26 04:41:04.035404',2,2),(68,'Jacob Walker','UI Engineer at UIWorks','2024-07-26 04:23:55.267814',NULL,NULL,2),(69,'Mia Anderson','Application Developer at AppWorks','2024-07-26 04:23:55.299013',NULL,NULL,2),(70,'Aiden Clark','Senior DevOps Engineer at OpsCorp','2024-07-26 04:23:55.345306',NULL,NULL,2),(71,'Avery Lewis','Cloud Architect at CloudForge','2024-07-26 04:23:55.375500',NULL,NULL,2),(72,'Amelia Nelson','Digital Engineer at DigitLab','2024-07-26 04:23:55.422675',NULL,NULL,2),(73,'Oliver Scott','Big Data Engineer at BigDataWorks','2024-07-26 04:23:55.470336','2024-07-26 04:44:24.467531',3,2),(74,'Grace Collins','Product Development Engineer at ProdLab','2024-07-26 04:23:55.499796',NULL,NULL,2),(75,'Noah Wright','Cybersecurity Engineer at CyberCorp','2024-07-26 04:23:55.533064','2024-07-26 04:51:43.593202',6,2),(76,'Ella Martinez','Web Solutions Engineer at WebLab','2024-07-26 04:23:55.564539','2024-07-26 04:48:29.103945',5,2),(77,'Benjamin Lee','Software Tester at TestLab','2024-07-26 04:23:55.595505','2024-07-26 04:51:48.537103',6,2),(78,'Windows 11 Pro','Windows 11 Pro License for 1 PC','2024-07-26 04:24:27.017440','2024-07-26 04:42:24.064281',2,3),(79,'Adobe Photoshop','Adobe Photoshop CC License','2024-07-26 04:24:27.050107','2024-07-26 04:46:50.744712',4,3),(80,'Microsoft Office 365','Office 365 License for 1 User','2024-07-26 04:24:27.081035','2024-07-26 04:46:45.820222',4,3),(81,'AutoCAD 2024','AutoCAD 2024 License for 1 User','2024-07-26 04:24:27.111906','2024-07-26 04:42:39.847835',2,3),(82,'MATLAB R2024','MATLAB R2024 License','2024-07-26 04:24:27.143683','2024-07-26 04:49:08.327404',5,3),(83,'Norton Security','Norton Antivirus License for 1 Year','2024-07-26 04:24:27.173615',NULL,NULL,3),(84,'VMware Workstation','VMware Workstation Pro License','2024-07-26 04:24:27.205851','2024-07-26 04:48:26.727756',5,3),(85,'Sublime Text','Sublime Text License','2024-07-26 04:24:27.236058','2024-07-26 04:49:12.548354',5,3),(86,'Zoom Pro','Zoom Pro Subscription for 1 Year','2024-07-26 04:24:27.267454',NULL,NULL,3),(87,'Slack Plus','Slack Plus Plan for 1 Year','2024-07-26 04:24:27.298598','2024-07-26 04:52:25.952038',6,3),(88,'GitKraken Pro','GitKraken Pro License for 1 Year','2024-07-26 04:24:27.328701',NULL,NULL,3),(89,'IntelliJ IDEA','IntelliJ IDEA Ultimate License','2024-07-26 04:24:27.361949',NULL,NULL,3),(90,'Sketch','Sketch Design Software License','2024-07-26 04:24:27.393098','2024-07-26 04:49:18.095910',5,3),(91,'Microsoft Visio','Microsoft Visio Professional License','2024-07-26 04:24:27.425234','2024-07-26 04:46:57.799038',4,3),(92,'Oracle Database','Oracle Database Enterprise Edition License','2024-07-26 04:24:27.471286','2024-07-26 04:52:20.442324',6,3),(93,'QuickBooks Online','QuickBooks Online Subscription for 1 Year','2024-07-26 04:24:27.516671','2024-07-26 04:49:21.986369',5,3),(94,'CyberLink PowerDirector','PowerDirector Video Editing Software License','2024-07-26 04:24:27.563761',NULL,NULL,3),(95,'CorelDRAW','CorelDRAW Graphics Suite License','2024-07-26 04:24:27.595286','2024-07-26 04:42:31.113770',2,3),(96,'WinRAR','WinRAR License for 1 User','2024-07-26 04:24:27.610817','2024-07-26 04:45:09.715604',3,3),(97,'Final Cut Pro','Final Cut Pro License for Mac','2024-07-26 04:24:27.657725','2024-07-26 04:45:22.877536',3,3),(98,'Revit','Revit Software License for 1 User','2024-07-26 04:24:27.689135','2024-07-26 04:41:06.821613',2,3),(99,'Ableton Live','Ableton Live Music Production Software License','2024-07-26 04:24:27.736651','2024-07-26 04:45:05.406915',3,3),(100,'ESET NOD32','ESET NOD32 Antivirus License for 1 Year','2024-07-26 04:24:27.766958',NULL,NULL,3),(101,'SketchUp Pro','SketchUp Pro License for 1 Year','2024-07-26 04:24:27.812399','2024-07-26 04:52:24.040487',6,3),(102,'Seating Space','Google Office','2024-07-26 04:26:51.391404','2024-07-26 04:41:16.210638',2,1),(103,'Seating Space','Google Office','2024-07-26 04:26:51.394874','2024-07-26 04:44:39.197375',3,1),(104,'Seating Space','Google Office','2024-07-26 04:26:51.398865','2024-07-26 04:44:43.887159',3,1),(105,'Seating Space','Google Office','2024-07-26 04:26:51.402889','2024-07-26 04:44:47.441960',3,1),(106,'Seating Space','Google Office','2024-07-26 04:26:51.407922','2024-07-26 04:44:50.443086',3,1),(107,'Seating Space','Google Office','2024-07-26 04:26:51.411911','2024-07-26 04:46:10.075132',4,1),(108,'Seating Space','Google Office','2024-07-26 04:26:51.415900','2024-07-26 04:48:12.116226',5,1),(109,'Seating Space','Google Office','2024-07-26 04:26:51.418892','2024-07-26 04:46:27.281977',4,1),(110,'Seating Space','Google Office','2024-07-26 04:26:51.423956',NULL,NULL,1),(111,'Seating Space','Google Office','2024-07-26 04:26:51.426948',NULL,NULL,1),(112,'Seating Space','Google Office','2024-07-26 04:26:51.431602','2024-07-26 04:46:32.396851',4,1),(113,'Seating Space','Google Office','2024-07-26 04:26:51.435158',NULL,NULL,1),(114,'Seating Space','Apple Office','2024-07-26 04:27:01.599523','2024-07-26 04:44:56.480390',3,1),(115,'Seating Space','Apple Office','2024-07-26 04:27:01.603330','2024-07-26 04:46:35.368021',4,1),(116,'Seating Space','Apple Office','2024-07-26 04:27:01.607322','2024-07-26 04:48:30.791616',5,1),(117,'Seating Space','Apple Office','2024-07-26 04:27:01.610183',NULL,NULL,1),(118,'Seating Space','X office','2024-07-26 04:27:13.993340',NULL,NULL,1),(119,'Seating Space','X office','2024-07-26 04:27:13.997557','2024-07-26 04:41:24.913243',2,1),(120,'Seating Space','X office','2024-07-26 04:27:14.001543',NULL,NULL,1),(121,'Seating Space','X office','2024-07-26 04:27:14.005655','2024-07-26 04:52:09.941757',6,1),(122,'Seating Space','X office','2024-07-26 04:27:14.008495','2024-07-26 04:52:13.103672',6,1),(123,'Seating Space','X office','2024-07-26 04:27:14.013024','2024-07-26 04:52:14.995037',6,1),(124,'Seating Space','X office','2024-07-26 04:27:14.016359','2024-07-26 04:52:11.608836',6,1),(125,'Seating Space','X office','2024-07-26 04:27:14.019937',NULL,NULL,1),(126,'Seating Space','X office','2024-07-26 04:27:14.022956','2024-07-26 04:41:39.860034',2,1),(127,'Seating Space','X office','2024-07-26 04:27:14.027108','2024-07-26 04:52:17.063058',6,1),(128,'Seating Space','Meta Office','2024-07-26 04:27:38.271508','2024-07-26 04:48:33.031118',5,1),(129,'Seating Space','Meta Office','2024-07-26 04:27:38.276460','2024-07-26 04:46:39.582485',4,1),(130,'Seating Space','Meta Office','2024-07-26 04:27:38.279987',NULL,NULL,1),(131,'Company Vehicle - Sedan','Sedan vehicle available for company use','2024-07-26 04:35:29.576207','2024-07-26 04:50:45.271073',5,4),(132,'3D Printer','3D Printer for prototyping and modeling','2024-07-26 04:36:43.729477','2024-07-26 04:45:48.482968',3,4),(133,'Meeting Room','Meeting room available for use','2024-07-26 04:37:15.531244',NULL,NULL,4),(134,'Company Vehicle - SUV','SUV vehicle available for company use','2024-07-26 04:38:07.814918',NULL,NULL,4),(135,'Digital Camera','Digital camera available for events and documentation','2024-07-26 04:38:52.108189',NULL,NULL,4),(136,'Seating Space','Google Office-2','2024-07-26 04:47:40.444646',NULL,NULL,1),(137,'Seating Space','Google Office-2','2024-07-26 04:47:40.448212',NULL,NULL,1),(138,'Seating Space','Google Office-2','2024-07-26 04:47:40.452179',NULL,NULL,1),(139,'Seating Space','Google Office-2','2024-07-26 04:47:40.454373','2024-07-26 04:52:06.497281',6,1),(140,'Seating Space','Google Office-2','2024-07-26 04:47:40.458932','2024-07-26 04:48:36.402684',5,1),(141,'Seating Space','Google Office-2','2024-07-26 04:47:40.461880','2024-07-26 04:48:35.030711',5,1),(142,'Seating Space','Google Office-2','2024-07-26 04:47:40.465402','2024-07-26 04:48:41.522622',5,1),(143,'Seating Space','Google Office-2','2024-07-26 04:47:40.468961','2024-07-26 04:48:39.917285',5,1),(144,'Seating Space','Google Office-2','2024-07-26 04:47:40.472973','2024-07-26 04:48:38.251001',5,1),(145,'Seating Space','Google Office-2','2024-07-26 04:47:40.475942','2024-07-26 04:52:04.306344',6,1);
/*!40000 ALTER TABLE `mybench_app_resource` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mybench_app_resourcetype`
--

DROP TABLE IF EXISTS `mybench_app_resourcetype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mybench_app_resourcetype` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mybench_app_resourcetype`
--

LOCK TABLES `mybench_app_resourcetype` WRITE;
/*!40000 ALTER TABLE `mybench_app_resourcetype` DISABLE KEYS */;
INSERT INTO `mybench_app_resourcetype` VALUES (1,'seating_space'),(2,'engineer'),(3,'product_license'),(4,'others');
/*!40000 ALTER TABLE `mybench_app_resourcetype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mybench_app_user`
--

DROP TABLE IF EXISTS `mybench_app_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mybench_app_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  `user_type` smallint unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  CONSTRAINT `mybench_app_user_chk_1` CHECK ((`user_type` >= 0))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mybench_app_user`
--

LOCK TABLES `mybench_app_user` WRITE;
/*!40000 ALTER TABLE `mybench_app_user` DISABLE KEYS */;
INSERT INTO `mybench_app_user` VALUES (1,'pbkdf2_sha256$600000$Fn4NgZROvLvsXKeOJ3DIj5$zpJyyvippM2KxbBynlSkW+EWxXFRLqQNqYazwdrHNqw=','2024-07-26 04:54:25.281972',1,'sanket','','','sanketnitinmore@gmail.com',1,1,'2024-07-25 16:41:31.110364',1),(2,'pbkdf2_sha256$600000$ktqN9ZkxqDVzRBbf32qsgv$QVmYUpw9QtmB4IdHGoiWUaOTGsQU+8lELscgYnTP33U=','2024-07-26 04:40:44.714555',0,'Apple','','','',0,1,'2024-07-25 18:22:19.644036',1),(3,'pbkdf2_sha256$600000$eeNCQ2tjnimaBzjmGNbey0$aZvBwIhBOem4pxQsqPLY6FdJah3ULnyX+i7Vn+QDZ6A=','2024-07-26 04:44:05.475217',0,'Amazon','','','',0,1,'2024-07-25 18:22:40.589838',1),(4,'pbkdf2_sha256$600000$lSvtlwkl0eSu0qKYHlmtax$vZ3oBpa4Ds9M1xJsAaMoeMDx8uspE0uYzMrIpgaF//c=','2024-07-26 04:46:02.014719',0,'Google','','','',0,1,'2024-07-25 18:23:01.713164',1),(5,'pbkdf2_sha256$600000$wvmb5rW27mLy4jjTldsTyX$MMUnmJAQvSLgqG2MIVpCr+heVqO+hrZG4FyNjY6a98s=','2024-07-26 04:48:04.235255',0,'Meta','','','',0,1,'2024-07-25 18:23:21.472645',1),(6,'pbkdf2_sha256$600000$UmTj7RRvSOggevuuoyz47C$MH2cev2mcrKZx3M1+IA2ot6pD9soCTCIpT9pi2Qhbkk=','2024-07-26 04:50:54.573413',0,'X','','','',0,1,'2024-07-25 18:23:33.565436',1);
/*!40000 ALTER TABLE `mybench_app_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mybench_app_user_groups`
--

DROP TABLE IF EXISTS `mybench_app_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mybench_app_user_groups` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mybench_app_user_groups_user_id_group_id_5f683d14_uniq` (`user_id`,`group_id`),
  KEY `mybench_app_user_groups_group_id_d2a2243a_fk_auth_group_id` (`group_id`),
  CONSTRAINT `mybench_app_user_groups_group_id_d2a2243a_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `mybench_app_user_groups_user_id_67e126a0_fk_mybench_app_user_id` FOREIGN KEY (`user_id`) REFERENCES `mybench_app_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mybench_app_user_groups`
--

LOCK TABLES `mybench_app_user_groups` WRITE;
/*!40000 ALTER TABLE `mybench_app_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `mybench_app_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mybench_app_user_user_permissions`
--

DROP TABLE IF EXISTS `mybench_app_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `mybench_app_user_user_permissions` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mybench_app_user_user_pe_user_id_permission_id_40280662_uniq` (`user_id`,`permission_id`),
  KEY `mybench_app_user_use_permission_id_74870307_fk_auth_perm` (`permission_id`),
  CONSTRAINT `mybench_app_user_use_permission_id_74870307_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `mybench_app_user_use_user_id_6722b106_fk_mybench_a` FOREIGN KEY (`user_id`) REFERENCES `mybench_app_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mybench_app_user_user_permissions`
--

LOCK TABLES `mybench_app_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `mybench_app_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `mybench_app_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-26 11:57:08
